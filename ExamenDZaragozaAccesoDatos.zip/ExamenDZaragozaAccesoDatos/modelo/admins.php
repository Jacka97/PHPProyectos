<?php

//Usuarios y contraseñas permitidas
$usu1 = "administrador";
$pass1 = "1234";
$usu2 = "Dios";
$pass2 = "123456";

?>